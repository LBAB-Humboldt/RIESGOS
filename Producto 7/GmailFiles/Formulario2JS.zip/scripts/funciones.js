/*  Secuencias de Scripting  */
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
	var x = 0;
	var y = "Web";
	var z = 22.323;

	function mostrarValores()
	{
		/*
		alert ("Valor de x: " + x);
		alert ('Valor de y: ' + y);
		alert ("Valor de z: " + z);
		*/

		console.log ("Valor de x: " + x);
		console.log ('Valor de y: ' + y);
		console.log ("Valor de z: " + z);

		var a = 20;
		var b = 23;

		if (a === b)
		{
			alert ("Los valores son iguales");
		}
		else
		if (a !== b)
		{
			alert ("los valores son diferentes");
		}

		var n = 27;
		alert ("Raiz cubica de " + n + " es " + Math.pow(n,1/4));

	}

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
function obtenerElementoFormulario()
{
	var valor = "";
	valor = document.getElementById("nombrePersona").value;
	alert ("objeto de campo de texto: " + valor);
	console.log (valor);
}


function getGET()
{
        // capturamos la url
        var loc = document.location.href;
        console.log ("URI de origen = " + loc);
        // si existe el interrogante
        var get = {};
        if(loc.indexOf('?')>0)
        {
            // cogemos la parte de la url que hay despues del interrogante
            var getString = loc.split('?')[1];
            // obtenemos un array con cada clave=valor
            var GET = getString.split('&');

            var valora = "";
 
            // recorremos todo el array de valores
            for(var i = 0, l = GET.length; i < l; i++)
            {
                var tmp = GET[i].split('=');
                get[tmp[0]] = unescape(decodeURI(tmp[1]));
                //alert ("Variable: " + tmp);
            }
        }

        return get;
}

function obtenerProfesion(codigoprofesion)
{
	var profesion = "";
	switch (codigoprofesion)
	{
		case 1:
				profesion = "Ingeniero";
				break;
		case 2:
				profesion = "Médico";
				break;
		default:
				profesion = "Abogado";
				break;
	}

	return (profesion);
}

function obtenerValoresPaginaOrigen()
{
	var valoresPagina = getGET();
	console.log (valoresPagina);
	//console.log ("valor 1: " + valoresPagina["descripcion"]);
	var nombre = valoresPagina["nombrePersona"];
	document.getElementById("nombre").innerHTML = nombre;
	document.getElementById("profesion").innerHTML = obtenerProfesion(valoresPagina["listaprofesiones"]);
	document.getElementById("descripcion").innerHTML = valoresPagina["descripcion"];

}

function mostrarRequest()
{
	var nombre = document.getElementById("nombrePersona").value;
	var descripcion = document.getElementById("descripcion").value;
	var etiqueta = document.getElementById("botonAceptar").value;

	var valoresFormulario = nombre + "\n" +
							descripcion + "\n" +
							etiqueta;

	alert (valoresFormulario);
}